﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using IanFlannery_S00209155;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestIncreaseRent()
        {
                //ARRANGE
                RentalProperty rental1 = new RentalProperty();
                decimal expectedBal = 200m;


                //ACT
                rental1.IncreaseRent(200m);


                //ASSERT
                Assert.AreEqual(expectedBal, rental1.Price);
        }
    }
}
