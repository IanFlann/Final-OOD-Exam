﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IanFlannery_S00209155
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// Github Link : https://github.com/IanFlann/Final_OOD_Exam
    public partial class MainWindow : Window
    {
        static List<RentalProperty> AllPropertiesList = new List<RentalProperty>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            RentalProperty.PropertyData db = new RentalProperty.PropertyData();

            var query = from rp in db.Properties
                        orderby rp.Price ascending
                        select rp;

            AllPropertiesList = query.ToList();
            lstbxProperties.ItemsSource = AllPropertiesList.ToList();
        }

        private void lstbxProperties_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RentalProperty selectedItem = (RentalProperty)lstbxProperties.SelectedItem;

            if (selectedItem != null)
                txtblkDesc.Text = selectedItem.Description;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            Window2 newWin = new Window2();
            newWin.Show();
        }
    }
}
