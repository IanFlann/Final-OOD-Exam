﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace IanFlannery_S00209155
{
    public class RentalProperty
    {
        public int ID { get; set; }
        public string RentalType { get; set; } //had to change to string as the enum wasnt working 
        public string Location { get; set; }
        public decimal Price { get; set; }
        public string Description { get; set; }
        public string ImagePath { get; set; }

        public RentalProperty()
        {

        }

        public void IncreaseRent(decimal percentageAmount)
        {
            if(percentageAmount != 0)
            {
                Price = Price * percentageAmount;
            }
        }

        public class PropertyData : DbContext
        {
            public PropertyData() : base("MyPropertyData2") { }

            public DbSet<RentalProperty> Properties { get; set; }
        }

        public override string ToString()
        {
            return String.Format($"{Location}  {Price}");
        }
    }
}
